﻿
using HarmonyLib;
using System;

public class SCoreModEvents
{

    public static void Init()
    {
        // When player starts a game
       // ModEvents.GameShutdown.RegisterHandler(new Action(FireManager.Instance.CleanUp));
      //  ModEvents.PlayerSpawnedInWorld.RegisterHandler(new Action<ClientInfo, RespawnType, Vector3i>(FireManager.Instance.Init));

    }
}

